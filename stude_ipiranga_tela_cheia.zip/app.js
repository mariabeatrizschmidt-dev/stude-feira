// STUDE — Ipiranga (PR). Edite a senha abaixo antes de publicar.
const ADMIN_PASSWORD = "stude2026";
const DEFAULT_VIDEOS = Array.from({length:7},(_,i)=>({
  id:i+1,
  title:`Vídeo ${String(i+1).padStart(2,"0")}`,
  subtitle:"Ipiranga (PR) — Antigamente e Atualmente",
  description:"Memórias, lugares e transformações da nossa cidade.",
  src:`assets/videos/video-${String(i+1).padStart(2,"0")}.mp4`,
  cover:""
}));
const STORAGE_KEY="stude-ipiranga-metadata-v1";
const DB_NAME="stude-ipiranga-media";
let videos=loadMetadata();
let currentIndex=0;
const player=document.querySelector("#player");
const list=document.querySelector("#videoList");
const empty=document.querySelector("#emptyState");

function loadMetadata(){
  try{const saved=JSON.parse(localStorage.getItem(STORAGE_KEY));if(Array.isArray(saved)&&saved.length===7)return saved;}catch(e){}
  return structuredClone(DEFAULT_VIDEOS);
}
function saveMetadata(){localStorage.setItem(STORAGE_KEY,JSON.stringify(videos));}
function escapeHTML(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderList(){
  list.innerHTML=videos.map((v,i)=>`<button class="video-card ${i===currentIndex?"active":""}" data-index="${i}" aria-label="Assistir ${escapeHTML(v.title)}">
    <span class="thumb" style="${v.cover?`background-image:linear-gradient(0deg,#07111f55,#07111f22),url('${escapeHTML(v.cover)}');background-size:cover;background-position:center`:''}">
      <span class="thumb-play">▶</span><span class="thumb-number">${String(i+1).padStart(2,"0")}</span>
    </span><span class="card-copy"><span class="card-index">EPISÓDIO ${String(i+1).padStart(2,"0")}</span><strong>${escapeHTML(v.title)}</strong><small>${escapeHTML(v.subtitle)}</small></span>
  </button>`).join("");
  document.querySelector("#videoCount").textContent=String(videos.length).padStart(2,"0");
  list.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>playVideo(Number(b.dataset.index),true)));
}
async function getStoredVideo(id){return new Promise(resolve=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>req.result.createObjectStore("videos");req.onsuccess=()=>{const db=req.result;const tx=db.transaction("videos","readonly");const r=tx.objectStore("videos").get(id);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>resolve(null)};req.onerror=()=>resolve(null)});}
async function playVideo(index,byUser=false){
  currentIndex=(index+7)%7;const v=videos[currentIndex];
  renderList();document.querySelector("#playingTitle").textContent=v.title;document.querySelector("#playingSubtitle").textContent=v.subtitle;
  player.pause();if(player.dataset.objectUrl){URL.revokeObjectURL(player.dataset.objectUrl);delete player.dataset.objectUrl;}
  const stored=await getStoredVideo(v.id);
  player.src=stored?URL.createObjectURL(stored):v.src;
  if(stored)player.dataset.objectUrl=player.src;
  empty.classList.add("hidden");
  try{await player.play();}catch(e){if(byUser){/* O navegador pode exigir um novo toque para liberar áudio. */}empty.classList.remove("hidden");}
  renderList();
}
player.addEventListener("ended",()=>playVideo((currentIndex+1)%7));
player.addEventListener("error",()=>{empty.classList.remove("hidden");document.querySelector("#playingTitle").textContent="Vídeo ainda não disponível";document.querySelector("#playingSubtitle").textContent="Adicione o arquivo correspondente no painel administrativo.";});
function openAdmin(){document.querySelector("#adminModal").classList.add("open");document.querySelector("#adminModal").setAttribute("aria-hidden","false");}
function closeAdmin(){document.querySelector("#adminModal").classList.remove("open");document.querySelector("#adminModal").setAttribute("aria-hidden","true");}
document.querySelector("#adminOpen").addEventListener("click",openAdmin);
document.querySelector("#adminClose").addEventListener("click",closeAdmin);
document.querySelector("#adminModal").addEventListener("click",e=>{if(e.target.id==="adminModal")closeAdmin();});
document.querySelector("#loginButton").addEventListener("click",()=>{
  const pass=document.querySelector("#adminPassword").value;
  if(pass!==ADMIN_PASSWORD){document.querySelector("#loginError").textContent="Senha incorreta. Tente novamente.";return;}
  document.querySelector("#loginError").textContent="";document.querySelector("#loginView").classList.add("hidden");document.querySelector("#editorView").classList.remove("hidden");renderEditor();
});
document.querySelector("#adminPassword").addEventListener("keydown",e=>{if(e.key==="Enter")document.querySelector("#loginButton").click();});
document.querySelector("#logoutButton").addEventListener("click",()=>{document.querySelector("#editorView").classList.add("hidden");document.querySelector("#loginView").classList.remove("hidden");document.querySelector("#adminPassword").value="";});
function renderEditor(){
  document.querySelector("#editorList").innerHTML=videos.map((v,i)=>`<div class="editor-item" data-id="${v.id}">
    <h3>VÍDEO ${String(i+1).padStart(2,"0")}</h3><div class="edit-grid">
      <div class="edit-field"><label>TÍTULO</label><input data-field="title" value="${escapeHTML(v.title)}"></div>
      <div class="edit-field"><label>SUBTÍTULO</label><input data-field="subtitle" value="${escapeHTML(v.subtitle)}"></div>
      <div class="edit-field full"><label>DESCRIÇÃO</label><textarea data-field="description">${escapeHTML(v.description)}</textarea></div>
      <div class="edit-field full"><label>IMAGEM DE CAPA (URL opcional)</label><input data-field="cover" value="${escapeHTML(v.cover)}" placeholder="https://..."></div>
    </div>
    <label class="file-label">↥ Substituir arquivo de vídeo <input type="file" accept="video/*" data-video-file="${v.id}"></label>
  </div>`).join("");
}
function storeVideo(id,blob){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>req.result.createObjectStore("videos");req.onsuccess=()=>{const tx=req.result.transaction("videos","readwrite");tx.objectStore("videos").put(blob,id);tx.oncomplete=resolve;tx.onerror=reject};req.onerror=reject;});}
document.querySelector("#saveButton").addEventListener("click",async()=>{
  const items=[...document.querySelectorAll(".editor-item")];
  items.forEach((item,i)=>{item.querySelectorAll("[data-field]").forEach(el=>videos[i][el.dataset.field]=el.value.trim());});
  const uploads=[...document.querySelectorAll("[data-video-file]")].filter(el=>el.files[0]);
  try{for(const input of uploads)await storeVideo(Number(input.dataset.videoFile),input.files[0]);saveMetadata();renderList();document.querySelector("#playingTitle").textContent=videos[currentIndex].title;document.querySelector("#playingSubtitle").textContent=videos[currentIndex].subtitle;alert("Alterações salvas neste navegador!");}
  catch(e){alert("Não foi possível salvar um dos arquivos. Tente um vídeo menor ou outro navegador.");}
});
document.querySelector("#resetButton").addEventListener("click",()=>{if(confirm("Restaurar os títulos, subtítulos e descrições originais?")){videos=structuredClone(DEFAULT_VIDEOS);saveMetadata();renderEditor();renderList();}});
document.querySelector("#projectTitle").textContent="Ipiranga (PR)";
renderList();
playVideo(0,false);


// Tela cheia: o navegador exige uma ação do usuário para permitir a entrada.
const fullscreenButton=document.querySelector("#fullscreenToggle");
function updateFullscreenButton(){
  const active=!!document.fullscreenElement;
  document.body.classList.toggle("fullscreen-active",active);
  fullscreenButton.querySelector(".fullscreen-label").textContent=active?"SAIR DA TELA CHEIA":"TELA CHEIA";
  fullscreenButton.setAttribute("aria-label",active?"Sair da tela cheia":"Entrar em tela cheia");
  fullscreenButton.title=active?"Sair da tela cheia (Esc)":"Entrar em tela cheia (F)";
}
async function toggleFullscreen(){
  try{
    if(!document.fullscreenElement){await document.documentElement.requestFullscreen();}
    else{await document.exitFullscreen();}
  }catch(error){alert("Não foi possível ativar a tela cheia neste navegador. Tente pressionar F11.");}
}
fullscreenButton.addEventListener("click",toggleFullscreen);
document.addEventListener("fullscreenchange",updateFullscreenButton);
document.addEventListener("keydown",event=>{
  if(event.key.toLowerCase()==="f" && !event.ctrlKey && !event.metaKey && !event.altKey && !["INPUT","TEXTAREA"].includes(document.activeElement.tagName)){
    event.preventDefault();toggleFullscreen();
  }
});
updateFullscreenButton();
